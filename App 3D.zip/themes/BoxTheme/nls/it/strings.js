define({
  "_themeLabel": "Tema Riquadro",
  "_layout_default": "Layout predefinito",
  "_layout_top": "Layout in alto"
});