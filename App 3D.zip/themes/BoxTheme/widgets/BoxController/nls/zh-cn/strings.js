define({
  "_widgetLabel": "盒子控制器"
});