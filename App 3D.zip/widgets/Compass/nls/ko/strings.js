define({
  "_widgetLabel": "나침반"
});