define({
  "_widgetLabel": "कंपास"
});