define({
  "_widgetLabel": "罗盘仪"
});