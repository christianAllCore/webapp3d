define({
  "_widgetLabel": "เข็มทิศ"
});