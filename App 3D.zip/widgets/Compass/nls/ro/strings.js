define({
  "_widgetLabel": "Busolă"
});