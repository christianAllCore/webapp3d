define({
  "_widgetLabel": "sekunder"
});