define({
  "_widgetLabel": "Kompass"
});