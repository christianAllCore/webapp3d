define({
  "_widgetLabel": "Kompasas"
});