define({
  "_widgetLabel": "Kompas"
});