define({
  "_widgetLabel": "Πυξίδα"
});