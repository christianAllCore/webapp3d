define({
  "_widgetLabel": "Galerija kartografskih podloga"
});