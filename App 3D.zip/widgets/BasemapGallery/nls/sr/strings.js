define({
  "_widgetLabel": "Galerija pozadinskih mapa"
});