define({
  "_widgetLabel": "Galerie de hărţi fundal"
});