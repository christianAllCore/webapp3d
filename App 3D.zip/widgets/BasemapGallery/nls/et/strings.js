define({
  "_widgetLabel": "Aluskaardigalerii"
});