define({
  "_widgetLabel": "גלרית מפות בסיס"
});