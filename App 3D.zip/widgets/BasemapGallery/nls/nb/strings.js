define({
  "_widgetLabel": "Bakgrunnskartgalleri"
});