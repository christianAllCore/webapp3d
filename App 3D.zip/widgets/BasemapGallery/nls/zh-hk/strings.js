define({
  "_widgetLabel": "底圖庫"
});