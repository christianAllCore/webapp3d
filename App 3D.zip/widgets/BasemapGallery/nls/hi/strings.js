define({
  "_widgetLabel": "Basemap गैलरी"
});