define({
  "_widgetLabel": "Galeria de mapes base"
});