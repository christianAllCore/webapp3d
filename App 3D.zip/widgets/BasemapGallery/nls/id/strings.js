define({
  "_widgetLabel": "Galeri Peta Dasar"
});