define({
  "_widgetLabel": "Grundkartengalerie"
});