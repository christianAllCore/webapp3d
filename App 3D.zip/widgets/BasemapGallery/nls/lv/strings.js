define({
  "_widgetLabel": "Pamatkaršu galerija"
});