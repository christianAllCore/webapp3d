define({
  "_widgetLabel": "Alaptérkép-galéria"
});