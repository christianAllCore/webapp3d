define({
  "_widgetLabel": "Altlık Harita Galerisi"
});