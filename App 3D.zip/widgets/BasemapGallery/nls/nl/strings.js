define({
  "_widgetLabel": "Basiskaartgalerij"
});