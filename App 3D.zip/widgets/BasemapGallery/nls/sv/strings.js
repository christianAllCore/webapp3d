define({
  "_widgetLabel": "Baskartgalleri"
});