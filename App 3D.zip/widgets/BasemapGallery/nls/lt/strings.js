define({
  "_widgetLabel": "Pagrindo žemėlapiai"
});