define({
  "_widgetLabel": "Galerija temeljnih kart"
});