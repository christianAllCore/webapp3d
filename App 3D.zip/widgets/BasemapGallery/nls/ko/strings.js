define({
  "_widgetLabel": "베이스맵 갤러리"
});