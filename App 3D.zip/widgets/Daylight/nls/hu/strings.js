define({
  "_widgetLabel": "Napfény",
  "dragSunSliderText": "Húzza a csúszkát a napszak módosításához.",
  "directShadow": "Közvetlen árnyék (napfénytől)",
  "diffuseShadow": "Diffúz árnyékok (környezeti takarás)",
  "shadowing": "Árnyékok"
});