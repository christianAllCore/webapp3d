define({
  "_widgetLabel": "Dagslys",
  "dragSunSliderText": "Træk skyderen for at ændre tidspunkt.",
  "directShadow": "Direkte skygge (kastet af solskinnet)",
  "diffuseShadow": "Diffuse skygger (omgivende okklusion)",
  "shadowing": "Skygger"
});