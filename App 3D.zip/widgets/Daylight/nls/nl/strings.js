define({
  "_widgetLabel": "Daglicht",
  "dragSunSliderText": "Sleep de schuifregelaar om de tijd te wijzigen.",
  "directShadow": "Directe schaduw (door zonlicht)",
  "diffuseShadow": "Diffuse schaduwen (omgevingsverberging)",
  "shadowing": "Schaduwen"
});