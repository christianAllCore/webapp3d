define({
  "_widgetLabel": "Siang hari",
  "dragSunSliderText": "Seret pengatur untuk mengubah waktu.",
  "directShadow": "Bayangan langsung (terkena oleh sinar matahari)",
  "diffuseShadow": "Bayangan difusi (oklusi ambien)",
  "shadowing": "Pembayangan"
});