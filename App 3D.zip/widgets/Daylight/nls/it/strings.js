define({
  "_widgetLabel": "Ora legale",
  "dragSunSliderText": "Trascinare il cursore per cambiare l'ora del giorno.",
  "directShadow": "Ombra diretta (da luce solare)",
  "diffuseShadow": "Ombre diffuse (occlusione ambientale)",
  "shadowing": "Ombreggiatura"
});