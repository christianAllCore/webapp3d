define({
  "_widgetLabel": "Danje svjetlo",
  "dragSunSliderText": "Povucite klizač da biste promijenili doba dana.",
  "directShadow": "Izravna sjena (koju baca sunčevo svjetlo)",
  "diffuseShadow": "Difuzna sjena (zakrivanje okoline)",
  "shadowing": "Sjenčanje"
});