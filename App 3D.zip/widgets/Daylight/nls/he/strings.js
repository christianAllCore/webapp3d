define({
  "_widgetLabel": "אור יום",
  "dragSunSliderText": "גרור את המחוון כדי לשנות את השעה ביום.",
  "directShadow": "צל ישיר (נוצר על ידי אור השמש)",
  "diffuseShadow": "צל מפוזר (נטמע בסביבה)",
  "shadowing": "הצללה"
});