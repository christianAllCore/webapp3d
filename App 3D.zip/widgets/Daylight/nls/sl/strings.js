define({
  "_widgetLabel": "Dnevna svetloba",
  "dragSunSliderText": "Povlecite drsnik za spreminjanje časa.",
  "directShadow": "Neposredna senca (povzroči jo sončna svetloba)",
  "diffuseShadow": "Difuzne sence (zakrivanje okolice)",
  "shadowing": "Senčenje"
});