define({
  "_widgetLabel": "Luz do Dia",
  "dragSunSliderText": "Arraste o controle deslizante para alterar a hora do dia.",
  "directShadow": "Sombra direta (iniciado pela luz do sol)",
  "diffuseShadow": "Sombras difusas (oclusão do ambiente)",
  "shadowing": "Sombreamento"
});